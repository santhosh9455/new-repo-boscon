package com.project.boscon.Config;

import com.project.boscon.Model.CoordinatorModel;
import com.project.boscon.Model.UserModel;
import com.project.boscon.Model.adminModel;
import com.project.boscon.Service.CoordinatorService;
import com.project.boscon.Service.UserService;
import com.project.boscon.Service.adminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private UserService userService;

    @Autowired
    private CoordinatorService coordinatorService;

    @Autowired
    private adminService adminService;

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> {
            UserModel user = userService.getUserByMobileNo(username);
            if (user != null) {
                return org.springframework.security.core.userdetails.User
                        .withUsername(user.getMobileNo())
                        .password(user.getPassword())
                        .roles("ROLE_" + user.getRole())
                        .build();
            }

            CoordinatorModel coordinator = coordinatorService.findByUserName(username);
            if (coordinator != null) {
                return org.springframework.security.core.userdetails.User
                        .withUsername(coordinator.getUserName())
                        .password(coordinator.getPassword())
                        .roles("ROLE_" + coordinator.getRole())
                        .build();
            }

            adminModel admin = adminService.findByUserName(username);
            if (admin != null) {
                return org.springframework.security.core.userdetails.User
                        .withUsername(admin.getUserName())
                        .password(admin.getPassword())
                        .roles("ROLE_" + admin.getRole())
                        .build();
            }

            throw new UsernameNotFoundException("User not found with username/mobileNo: " + username);
        };
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/","/register","/register.html", "/login.html", "/index.html", "/about.html", "/rules.html", "/coordinator.html").permitAll()
                        .requestMatchers("/user-dashboard","/user/**").hasRole("USER")
                        .requestMatchers("/coordinator-login", "/coordinator-dashboard").hasRole("COORDINATOR")
                        .requestMatchers("/admin-login", "/admin-dashboard", "/admin/create-coordinator").hasRole("ADMIN")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login.html")
                        .usernameParameter("username")
                        .passwordParameter("password")
                        .successHandler((request, response, authentication) -> {
                            String username = authentication.getName();
                            String role = authentication.getAuthorities().iterator().next().getAuthority().replace("ROLE_", "");
                            switch (role) {
                                case "USER":
                                    response.sendRedirect("/user-dashboard");
                                    break;
                                case "COORDINATOR":
                                    response.sendRedirect("/coordinator-dashboard");
                                    break;
                                case "ADMIN":
                                    response.sendRedirect("/admin-dashboard");
                                    break;
                                default:
                                    response.sendRedirect("/login?error");
                            }
                        })
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/index.html")
                        .permitAll()
                );
        return http.build();
    }
}
