package com.project.boscon.Controller;

import com.project.boscon.Model.adminModel;
import com.project.boscon.Service.adminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class adminController {

    @Autowired
    public adminService adminService;

    @GetMapping("/admin-login.html")
    public String adminLoginForm() {
        return "admin-login";
    }

    @GetMapping("/admin-dashboard")
    public String adminDashboard() {
        return "admin-dashboard";
    }

    @PostMapping("/add-admin")
    public String addAdmin(@ModelAttribute adminModel admin, Model model) {
        adminService.addadmin(admin);
        List<adminModel> existingAdmins = adminService.getAllAdmin();
        model.addAttribute("User", existingAdmins);
        return "admin-dashboard";
    }
}