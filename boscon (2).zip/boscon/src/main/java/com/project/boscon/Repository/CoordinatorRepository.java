package com.project.boscon.Repository;

import com.project.boscon.Model.CoordinatorModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoordinatorRepository extends JpaRepository<CoordinatorModel, Long> {
    CoordinatorModel findByUserName(String userName);
}