package com.project.boscon.Controller;

import com.project.boscon.Model.UserModel;
import com.project.boscon.Service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/coordinator.html")
    public String coordinator() {
        return "coordinator";
    }

    @GetMapping("/login.html")
    public String loginUser() {
        return "login";
    }

    @GetMapping("/about.html")
    public String about() {
        return "about";
    }


    @GetMapping("/register.html")
    public String register(Model model) {
        logger.info("Displaying registration form");
        model.addAttribute("user", new UserModel());
        return "register";
    }

    @GetMapping("/rules.html")
    public String rules() {
        return "rules";
    }

    @GetMapping("/index.html")
    public String home() {
        return "index";
    }

    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute UserModel user, BindingResult result, Model model) {
        logger.info("Received registration request for mobileNo: {}", user.getMobileNo());
        if (result.hasErrors()) {
            logger.warn("Validation errors: {}", result.getAllErrors());
            return "register";
        }
        if (userService.getUserByMobileNo(user.getMobileNo()) != null) {
            logger.warn("Mobile number already registered: {}", user.getMobileNo());
            model.addAttribute("error", "Mobile number already registered");
            return "register";
        }
        try {
            userService.registerUser(user);
            logger.info("User registered successfully: {}", user.getMobileNo());
            return "redirect:/login.html?registered";
        } catch (Exception e) {
            logger.error("Registration failed for mobileNo: {}", user.getMobileNo(), e);
            model.addAttribute("error", "Registration failed: " + e.getMessage());
            return "register";
        }
    }

    @GetMapping("/user-dashboard")
    public String userDashboard(Model model) {
        return "user-dashboard";
    }
}