package com.project.boscon.Service;

import com.project.boscon.Model.UserModel;
import com.project.boscon.Repository.UserRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Transactional
    public UserModel registerUser(UserModel user) {
        logger.info("Registering user with mobileNo: {}", user.getMobileNo());
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        UserModel savedUser = userRepository.save(user);
        logger.info("User saved to database with ID: {}", savedUser.getId());
        return savedUser;
    }

    public UserModel getUserByMobileNo(String mobileNo) {
        logger.debug("Fetching user with mobileNo: {}", mobileNo);
        return userRepository.findByMobileNo(mobileNo);
    }

    public boolean authenticateUser(String mobileNo, String password) {
        logger.debug("Authenticating user with mobileNo: {}", mobileNo);
        UserModel user = getUserByMobileNo(mobileNo);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            logger.info("Authentication successful for user: {}", mobileNo);
            return true;
        }
        logger.warn("Authentication failed for user: {}", mobileNo);
        return false;
    }
}
