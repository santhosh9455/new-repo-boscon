package com.project.boscon.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "user_table")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key with auto-increment

    @Column(unique = true, nullable = false)
    private String mobileNo; // Unique constraint ensures no duplicate mobile numbers

    private String password;
    private String studentName;
    private String college;
    private String department;
    private String email;
    private String event1;
    private String event2;
    private String role = "USER";
}
