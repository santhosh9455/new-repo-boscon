package com.project.boscon.Repository;

import com.project.boscon.Model.UserModel;
import com.project.boscon.Model.adminModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface adminRepo extends JpaRepository<adminModel,Long> {
    adminModel findByuserName(String userName);

    adminModel findByUserName(String userName);
}
