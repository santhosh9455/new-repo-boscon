package com.project.boscon.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;

@Entity(name = "event_table")
public class EventModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Event name is required")
    private String eventName;

    private String winner; // MobileNo of the winning participant (UserModel)
    private String score;  // Optional: Can be a string for flexibility (e.g., "95/100" or "1st Place")

    public EventModel() {}

    public EventModel(String eventName, String winner, String score) {
        this.eventName = eventName;
        this.winner = winner;
        this.score = score;
    }

    // Getters and setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }
    public String getWinner() { return winner; }
    public void setWinner(String winner) { this.winner = winner; }
    public String getScore() { return score; }
    public void setScore(String score) { this.score = score; }
}
