package com.project.boscon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BosconApplication {

	public static void main(String[] args) {
		SpringApplication.run(BosconApplication.class, args);
	}

}
