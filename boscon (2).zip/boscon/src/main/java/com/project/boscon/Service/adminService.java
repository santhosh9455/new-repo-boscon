package com.project.boscon.Service;

import com.project.boscon.Model.adminModel;
import com.project.boscon.Repository.adminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class adminService {

    @Autowired
    private adminRepo adminRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public adminModel addadmin(adminModel admin) {
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        return adminRepository.save(admin);
    }

    public adminModel findByUserName(String userName) {
        return adminRepository.findByUserName(userName);
    }

    public boolean authenticateadmin(String userName, String password) {
        adminModel admin = findByUserName(userName);
        return admin != null && passwordEncoder.matches(password, admin.getPassword());
    }

    public List<adminModel> getAllAdmin() {
        return adminRepository.findAll();
    }
}