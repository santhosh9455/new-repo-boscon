package com.project.boscon.Controller;

import com.project.boscon.Model.CoordinatorModel;
import com.project.boscon.Service.CoordinatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CoordinatorController {

    @Autowired
    private CoordinatorService coordinatorService;

    @GetMapping("/coordinator-login")
    public String showLoginPage(Model model) {
        model.addAttribute("active", "login");
        return "coordinator-login";
    }

    @PostMapping("/coordinator-login")
    public String login(@RequestParam String userName, @RequestParam String password, Model model) {
        if (coordinatorService.validateLogin(userName, password)) {
            CoordinatorModel coordinatorModel = coordinatorService.findByUserName(userName);
            model.addAttribute("coordinator", coordinatorModel); // Pass coordinator to session or next page
            return "redirect:/coordinator-dashboard";
        } else {
            model.addAttribute("error", "Invalid username or password");
            model.addAttribute("active", "login");
            return "coordinator-login";
        }
    }

    @GetMapping("/coordinator-dashboard")
    public String showDashboard(@RequestParam(required = false) String userName, Model model) {
        CoordinatorModel coordinator = coordinatorService.findByUserName(userName); // Ideally, use session or authentication principal
        if (coordinator != null) {
            model.addAttribute("coordinator", coordinator);
            model.addAttribute("eventParticipants", 10); // Replace with actual logic
            // Add logic to fetch participants for coordinator.event
            // model.addAttribute("participants", participantService.findByEvent(coordinator.getEvent()));
        }
        model.addAttribute("active", "dashboard");
        return "coordinator-dashboard";
    }
}