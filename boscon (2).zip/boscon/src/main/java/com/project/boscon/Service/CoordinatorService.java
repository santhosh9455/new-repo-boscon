package com.project.boscon.Service;

import com.project.boscon.Model.CoordinatorModel;
import com.project.boscon.Repository.CoordinatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CoordinatorService {

    @Autowired
    private CoordinatorRepository coordinatorRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public CoordinatorModel save(CoordinatorModel coordinator) {
        coordinator.setPassword(passwordEncoder.encode(coordinator.getPassword()));
        return coordinatorRepository.save(coordinator);
    }

    public CoordinatorModel findByUserName(String userName) {
        return coordinatorRepository.findByUserName(userName);
    }

    public boolean validateLogin(String userName, String password) {
        CoordinatorModel coordinator = findByUserName(userName);
        return coordinator != null && passwordEncoder.matches(password, coordinator.getPassword());
    }
}